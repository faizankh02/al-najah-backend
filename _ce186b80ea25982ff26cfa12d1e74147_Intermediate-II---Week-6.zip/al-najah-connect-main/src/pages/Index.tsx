import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import CategoryCard from "@/components/CategoryCard";
import InquiryForm from "@/components/InquiryForm";
import Footer from "@/components/Footer";

import handToolsImg from "@/assets/categories/hand-tools.jpg";
import powerToolsImg from "@/assets/categories/power-tools.jpg";
import fastenersImg from "@/assets/categories/fasteners.jpg";
import safetyImg from "@/assets/categories/safety-equipment.jpg";
import electricalImg from "@/assets/categories/electrical-lighting.jpg";
import plumbingImg from "@/assets/categories/plumbing.jpg";
import buildingImg from "@/assets/categories/building-materials.jpg";
import paintingImg from "@/assets/categories/painting.jpg";
import industrialImg from "@/assets/categories/industrial-supplies.jpg";

const categories = [
  {
    title: "Hand Tools",
    description: "Premium quality hammers, screwdrivers, wrenches, pliers, and complete hand tool sets for professional use.",
    image: handToolsImg,
    productCount: 150,
  },
  {
    title: "Power Tools",
    description: "Industrial-grade drills, grinders, saws, and power equipment from leading manufacturers.",
    image: powerToolsImg,
    productCount: 120,
  },
  {
    title: "Fasteners & Screws",
    description: "Comprehensive range of bolts, nuts, screws, anchors, and fastening solutions for all applications.",
    image: fastenersImg,
    productCount: 500,
  },
  {
    title: "Safety Equipment",
    description: "Complete safety gear including helmets, gloves, protective wear, and workplace safety solutions.",
    image: safetyImg,
    productCount: 200,
  },
  {
    title: "Electrical & Lighting",
    description: "Electrical supplies, LED lighting, cables, switches, and complete electrical fittings.",
    image: electricalImg,
    productCount: 180,
  },
  {
    title: "Plumbing & Fittings",
    description: "Quality pipes, valves, connectors, and complete plumbing solutions for commercial projects.",
    image: plumbingImg,
    productCount: 250,
  },
  {
    title: "Building Materials",
    description: "Cement, bricks, blocks, and essential construction materials for all building projects.",
    image: buildingImg,
    productCount: 100,
  },
  {
    title: "Painting & Finishing",
    description: "Professional painting supplies, brushes, rollers, and finishing materials for perfect results.",
    image: paintingImg,
    productCount: 130,
  },
  {
    title: "Miscellaneous Industrial Supplies",
    description: "Measuring tools, adhesives, tapes, and diverse industrial hardware for various applications.",
    image: industrialImg,
    productCount: 300,
  },
];

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <div id="hero">
          <Hero />
        </div>

        {/* Categories Section */}
        <section id="categories" className="py-16 bg-background">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Our Product Categories
              </h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Explore our comprehensive range of construction materials and industrial equipment
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {categories.map((category, index) => (
                <CategoryCard key={index} {...category} />
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Us Section */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Why Choose Al Najah Company?
              </h2>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-bold">✓</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Premium Quality</h3>
                <p className="text-primary-foreground/80">
                  All products sourced from trusted manufacturers with quality certifications
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-bold">⚡</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Fast Delivery</h3>
                <p className="text-primary-foreground/80">
                  Efficient logistics and delivery across UAE for timely project completion
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-bold">💰</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Competitive Pricing</h3>
                <p className="text-primary-foreground/80">
                  Best value for money with flexible bulk pricing for large orders
                </p>
              </div>
            </div>
          </div>
        </section>

        <InquiryForm />
      </main>

      <Footer />
    </div>
  );
};

export default Index;
