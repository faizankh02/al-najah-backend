import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Phone } from "lucide-react";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
    setIsMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 bg-card border-b border-border shadow-[var(--shadow-soft)]">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          <div className="flex items-center">
            <h1 className="text-xl md:text-2xl font-bold text-primary">
              Al Najah Company
            </h1>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection("hero")}
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection("categories")}
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Categories
            </button>
            <button 
              onClick={() => scrollToSection("inquiry-section")}
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Contact
            </button>
            <Button 
              onClick={() => scrollToSection("inquiry-section")}
              className="gap-2"
            >
              <Phone className="h-4 w-4" />
              Get Quote
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-md hover:bg-muted transition-colors"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-foreground" />
            ) : (
              <Menu className="h-6 w-6 text-foreground" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection("hero")}
                className="text-left px-4 py-2 text-foreground hover:bg-muted rounded-md transition-colors font-medium"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection("categories")}
                className="text-left px-4 py-2 text-foreground hover:bg-muted rounded-md transition-colors font-medium"
              >
                Categories
              </button>
              <button 
                onClick={() => scrollToSection("inquiry-section")}
                className="text-left px-4 py-2 text-foreground hover:bg-muted rounded-md transition-colors font-medium"
              >
                Contact
              </button>
              <div className="px-4">
                <Button 
                  onClick={() => scrollToSection("inquiry-section")}
                  className="w-full gap-2"
                >
                  <Phone className="h-4 w-4" />
                  Get Quote
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
