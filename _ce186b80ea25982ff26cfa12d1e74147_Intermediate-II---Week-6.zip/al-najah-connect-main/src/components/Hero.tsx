import { Button } from "@/components/ui/button";
import { Phone, Mail, MapPin } from "lucide-react";
import heroBanner from "@/assets/hero-banner.jpg";

const Hero = () => {
  const scrollToInquiry = () => {
    const inquirySection = document.getElementById("inquiry-section");
    inquirySection?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-[500px] md:min-h-[600px] flex items-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroBanner})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--hero-gradient-from))] via-[hsl(var(--hero-gradient-from))]/95 to-[hsl(var(--hero-gradient-to))]/85" />
      </div>
      
      <div className="container relative z-10 mx-auto px-4 py-16 md:py-20">
        <div className="max-w-3xl">
          <div className="mb-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
              Al Najah Company
            </h1>
            <p className="text-xl md:text-2xl text-white/90 font-medium">
              Your Trusted Partner in Construction Materials & Industrial Equipment
            </p>
          </div>
          
          <p className="text-lg text-white/80 mb-8 max-w-2xl">
            Supplying premium quality hand tools, power tools, safety equipment, fasteners, 
            and complete construction solutions to businesses across the UAE.
          </p>
          
          <div className="flex flex-wrap gap-4 mb-8">
            <Button 
              size="lg" 
              onClick={scrollToInquiry}
              className="bg-white text-primary hover:bg-white/90 shadow-lg font-semibold"
            >
              Get Best Quote
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-2 border-white text-white hover:bg-white hover:text-primary font-semibold"
            >
              View Products
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-6 text-white/90">
            <div className="flex items-center gap-2">
              <Phone className="h-5 w-5" />
              <span className="text-sm md:text-base">+971 XXX XXXX</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              <span className="text-sm md:text-base">info@alnajah.ae</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              <span className="text-sm md:text-base">Sharjah Airport Int'l Freezone</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
